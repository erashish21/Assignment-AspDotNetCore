﻿using AssignmentASPDOTNERCOREWEBAPI.Data;
using AssignmentASPDOTNERCOREWEBAPI.DTOs;
using AssignmentASPDOTNERCOREWEBAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AssignmentASPDOTNERCOREWEBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly ApplicationDbContext context;

        public UserController( ApplicationDbContext context)
        {
            this.context = context;
        }

        // Add/Update 
        [HttpPost("add-update")]
        public async Task<IActionResult> AddOrUpdateUser(UserDto userDto)
        {
            if (userDto == null)
                return BadRequest("Invalid user data.");

            User user;
            if (userDto.Id.HasValue && userDto.Id > 0)
            {
                user = await context.Users.Include(u => u.Addresses).FirstOrDefaultAsync(u => u.Id == userDto.Id);
                if (user == null)
                    return NotFound("User not found.");

                user.Name = userDto.Name;
                user.Email = userDto.Email;
                
                context.UserAddresses.RemoveRange(user.Addresses);

                user.Addresses = userDto.Addresses.Select(addr => new UserAddress { Address = addr, UserId = user.Id }).ToList();
            }
            else
            {
                // Add new user
                user = new User
                {
                    Name = userDto.Name,
                    Email = userDto.Email,
                    Addresses = userDto.Addresses.Select(addr => new UserAddress { Address = addr }).ToList()
                };
                context.Users.Add(user);
            }

            await context.SaveChangesAsync();
            return Ok("User saved successfully.");
        }
        //  Get User
        [HttpGet("get/{id}")]
        public async Task<IActionResult> GetUser(int id)
        {
            var user = await context.Users.Include(u => u.Addresses).FirstOrDefaultAsync(u => u.Id == id);

            if (user == null)
                return NotFound("User not found.");

            var userDto = new UserDto
            {
                Id = user.Id,
                Name = user.Name,
                Email = user.Email,
                Addresses = user.Addresses.Select(a => a.Address).ToList()
            };

            return Ok(userDto);
        }

    }
}

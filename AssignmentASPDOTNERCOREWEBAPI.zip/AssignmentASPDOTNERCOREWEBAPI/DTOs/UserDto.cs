﻿namespace AssignmentASPDOTNERCOREWEBAPI.DTOs
{
    public class UserDto
    {
        public int? Id { get; set; }  // Nullable for Add/Update
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public List<string> Addresses { get; set; } = new List<string>();
    }
}

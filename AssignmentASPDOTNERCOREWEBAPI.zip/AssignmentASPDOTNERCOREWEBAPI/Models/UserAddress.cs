﻿using System.ComponentModel.DataAnnotations;

namespace AssignmentASPDOTNERCOREWEBAPI.Models
{
    public class UserAddress
    {
        public int Id { get; set; }
        [Required]
        public string Address { get; set; } = string.Empty;
        public int UserId { get; set; }
        public User User { get; set; } = null!;

    }
}
